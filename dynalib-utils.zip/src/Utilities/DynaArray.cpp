//
// Created by Ken Kopelson on 14/10/17.
//

#include "DynaArrayImpl.h"

MAKE_ARRAYTYPE_INSTANCE(char, Char);
MAKE_ARRAYTYPE_INSTANCE(int, Int);
MAKE_ARRAYTYPE_INSTANCE(long, Long);

