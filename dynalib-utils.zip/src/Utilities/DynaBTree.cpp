#include "DynaBTreeImpl.h"
#include "DynaArrayImpl.h"
#include "DynaListImpl.h"
#include "IntWrapper.h"

MAKE_BTREETYPE_INSTANCE(Long, long, LL);
MAKE_LISTTYPE_INSTANCE(LLBTreeNode, LLBTreeNodeList);
