#include "DynaWaitQueue.h"

template <class T> int DynaWaitQueue<T>::NO_MAX_SIZE = 0;
