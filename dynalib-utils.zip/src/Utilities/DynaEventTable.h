//
// Created by Ken Kopelson on 26/03/18.
//

#ifndef DYNAEVENTTABLE_H
#define DYNAEVENTTABLE_H

struct EventHook {
    static int EventAllTypes;
    int eventType = EventAllTypes;

};

class DynaEventTable {

};


#endif //DYNAEVENTTABLE_H
