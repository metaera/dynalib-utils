//
// Created by Ken Kopelson on 26/03/18.
//

#ifndef IDYNAEVENT_H
#define IDYNAEVENT_H

class IDynaEvent {
public:
    virtual int getType() = 0;
};

#endif //IDYNAEVENT_H
