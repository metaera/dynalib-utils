//
// Created by Ken Kopelson on 20/05/18.
//

#ifndef INDEXCONFIG_H
#define INDEXCONFIG_H

// Uncomment the following to enable LONG index values, providing a massive amount of Cortex Memory storage
#define USE_LONG

#endif //INDEXCONFIG_H
