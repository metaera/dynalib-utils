//
// Created by Ken Kopelson on 14/10/17.
//

#include "DynaListImpl.h"
#include "String.h"

MAKE_LISTTYPE_INSTANCE(String, String);
