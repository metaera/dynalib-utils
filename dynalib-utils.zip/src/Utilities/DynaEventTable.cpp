//
// Created by Ken Kopelson on 26/03/18.
//

#include "DynaEventTable.h"

int EventHook::EventAllTypes = -1;
